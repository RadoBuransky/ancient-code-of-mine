<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <title>Kompas - komunitná pomoc a starostlivost</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" type="text/css" href="css/default.css">
    <link rel="stylesheet" type="text/css" href="css/menu.css">
    <link rel="icon" HREF="img/favico.png" type="image/png">
  </head>
  <body>
  	<!-- HEADER -->
  	<div class="Top">
  		<img src="img/logo-only-g.gif" alt="K" class="LogoOnly" />
  		<img src="img/logo-only.gif" alt="O" class="LogoOnly" />
  		<img src="img/logo-only-g.gif" alt="M" class="LogoOnly" />
  		<img src="img/logo-only-g.gif" alt="P" class="LogoOnly" />
  		<img src="img/logo-only-g.gif" alt="A" class="LogoOnly" />
  		<img src="img/logo-only-g.gif" alt="S" class="LogoOnly" />
  		<img src="img/logo.jpg" alt="Kompas n.o." class="Logo" />
  	</div>
  	<div class="BrownStripe"></div>
  	
  	<!-- MENU -->
  	<div class="GreenStripe">
  	<div id="MainMenu">
	  	<ul>
	  		<li><a href="#">Kto sme?<!--[if IE 7]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
	  			<ul>
	  				<li><a href="#">Vznik</a></li>
	  				<li><a href="#">Orgány</a></li>
	  				<li><a href="#">Štatút</a></li>
	  			</ul>
	  			<!--[if lte IE 6]></td></tr></table></a><![endif]-->
	  		</li>
	  		<li><a href="#">Naše ciele<!--[if IE 7]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
	  			<ul id="MainMenu2">
	  				<li><a href="#">Prioritné oblasti našej cinnosti</a></li>
	  				<li><a href="#">Formy realizácie našich cielov</a></li>
	  				<li><a href="#">Z coho vychádzame?</a></li>
	  			</ul>
	  			<!--[if lte IE 6]></td></tr></table></a><![endif]-->
	  		</li>
	  		<li><a href="#">Projekty<!--[if IE 7]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
	  			<ul>
	  				<li><a href="#" style="width: 200px">Program "TETRALÓG"</a></li>
	  			</ul>
	  			<!--[if lte IE 6]></td></tr></table></a><![endif]-->
	  		</li>
	  		<li><a href="#">Starostlivost<!--[if IE 7]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
	  			<ul id="MainMenu4">
	  				<li><a href="#">Komplexná siet starostlivosti o ludí s duševnými ochoreniami</a></li>
	  				<li><a href="#">Základne pojmy</a></li>
	  			</ul>
	  			<!--[if lte IE 6]></td></tr></table></a><![endif]-->
	  		</li>
	  		<li><a href="#">Odkazy<!--[if IE 7]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
	  			<ul>
	  				<li><a href="#">Partneri</a></li>
	  				<li><a href="#">Ostatné</a></li>
	  			</ul>
	  			<!--[if lte IE 6]></td></tr></table></a><![endif]-->
	  		</li>
	  		<li><a href="#">Podporte nás<!--[if IE 7]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
	  			<ul id="MainMenu6">
	  				<li><a href="#">Financným darom</a></li>
	  				<li><a href="#">Spoluprácou s nami</a></li>
	  			</ul>
	  			<!--[if lte IE 6]></td></tr></table></a><![endif]-->
	  		</li>
	  		<li><a href="#">Kontakt</a></li>
	  	</ul>
	  </div>
	  </div>
  	
  	<!-- CONTENT -->
  	<div class="Container">
  	</div>
  	
  	<!-- FOOTER -->
	</body>
</html>